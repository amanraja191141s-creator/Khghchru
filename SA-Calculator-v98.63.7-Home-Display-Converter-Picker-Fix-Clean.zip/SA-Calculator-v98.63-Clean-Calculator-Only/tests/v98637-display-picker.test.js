const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const js = fs.readFileSync(path.join(root, 'assets/js/app.js'), 'utf8');
const css = fs.readFileSync(path.join(root, 'assets/css/rebuild-v98.63.7-display-picker.css'), 'utf8');
const build = fs.readFileSync(path.join(root, 'scripts/prepare-android-web.mjs'), 'utf8');

test('currency and unit selectors are searchable independently', () => {
  assert.match(js, /const isCurrency = \/\^cur-\(from\|to\)\$\//);
  assert.match(js, /const isUnit = \/\^unit-\(from\|to\)\$\//);
  assert.match(js, /Search unit name or symbol/);
});

test('picker initially renders only the selected currency or unit', () => {
  assert.match(js, /if \(searchable && !query && index !== select\.selectedIndex\) return;/);
  assert.match(js, /if \(query && !\(optionLabel \+ ' ' \+ option\.value\)\.toLocaleLowerCase\(\)\.includes\(query\)\) return;/);
});

test('home display is capped to 700px and keypad buttons are compact', () => {
  assert.match(css, /max-width:700px/);
  assert.match(css, /width:88%/);
  assert.match(css, /height:86%/);
  assert.match(css, /min-height:42px/);
});

test('Android bundle build includes the new final CSS layer', () => {
  assert.match(build, /rebuild-v98\.63\.7-display-picker\.css/);
});
