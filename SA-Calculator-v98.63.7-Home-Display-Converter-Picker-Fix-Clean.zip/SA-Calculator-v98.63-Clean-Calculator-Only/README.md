# SA Calculator — v98.63

A mobile-first calculator application with standard and scientific calculation, history, favorites, themes, localization, tools, and converters. The Android app is packaged with Capacitor.

## Build and verify

Requirements: Node.js 22+, npm, Java 21, and Android SDK for APK builds.

```sh
npm install
npm test
npm run build:web
```

For Android, generate the native project once with `npx cap add android`, then run `npm run android:sync`. Build a debug APK with `npm run android:apk` where the Android SDK and Gradle requirements are installed.

The GitHub Actions workflow in `.github/workflows/main.yml` validates the exact source version and builds a debug APK.

Release: `1.98.63-v98.63` · Android versionCode `1098063`.

## 3. Calculator home — Basic

Standard arithmetic keypad and live expression/result display.

## 4. Scientific Calculator

Trigonometric, logarithmic, power, root, angle and memory functions.

## 5. Tools catalogue

Dedicated calculators and utilities.

## 7. History

Saved calculations with restore, copy, share and clear actions.

## 8. Favorites

Quick access to favorite tools.

## 9. Settings

Appearance, accent palette, localization and app preferences.

## 10. Dialogs, pickers, menus and feedback

Contextual dialogs and dedicated selection controls.

## 13. Regression and device test matrix

Automated source tests are available; physical device testing is a separate release check.

## Main screens

- **Calculator home — Basic:** standard arithmetic keypad and live expression/result display.
- **Scientific Calculator:** trigonometric, logarithmic, power, root, angle and memory functions.
- **Tools catalogue:** dedicated calculators and utilities.
- **Converters:** currency and unit conversion screens with searchable selectors.
- **History:** saved calculations with restore, copy, share and clear actions.
- **Favorites:** quick access to favorite tools.
- **Settings:** appearance, accent palette, localization and app preferences.

The keypad is numeric only; never render all currency country names or unit names among digit keys. Tool inputs use dedicated selectors where appropriate. Base-aware keypad. Date entry uses the native date picker where supported.


## Latest patch: v98.63.5

This patch retains the v98.63.2 Android recording fixes and v98.63.3 release verification correction, then removes the marked currency-picker text-flow, redundant exchange-rate metadata, and extra bottom-dock band. The package runtime identity remains `1.98.63-v98.63`; the patch label is v98.63.5. See `SCREENSHOT-REVIEW-v98.63.5.md`, `VIDEO-REVIEW-v98.63.2.md`, and `RELEASE-VERIFICATION.md`.


## v98.63.6 Android UI correction

This patch removes the duplicated Android bottom-safe-area reservation that left a visible blank band beneath the five-tab navigation, forces the currency picker into a fixed-header/optional-search/vertical-option-list layout, and removes the hidden currency keypad from layout flow. Android package identity remains `1.98.63-v98.63` (versionCode `1098063`) for this patch-only update. See `SCREENSHOT-REVIEW-v98.63.6.md` and `QA-RESULTS-v98.63.6.md`.
